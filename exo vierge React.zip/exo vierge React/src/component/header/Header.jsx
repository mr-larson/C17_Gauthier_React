/*-------------- lien JSX --------------*/
import Nav from './Nav'


import React, { Component } from 'react'

export default class Header extends Component {
    render() {
        return (
            <div>
                <Nav/>
            </div>
        )
    }
}
