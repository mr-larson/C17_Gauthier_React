import React from 'react'

export default function Section2() {
    return (
        <div>
            
        </div>
    )
}
